package main

import (
	"databases"
	"routes"
)

func main() {
	//setup database first
	config := databases.GetConfig()
	databases.SetupDatabase(config)

	//setup routes
	routes.Routes() 

	//GOLANG DEVELOPED BY : ARDI GUNAWAN -> ardigunawan1992@gmail.com
}

